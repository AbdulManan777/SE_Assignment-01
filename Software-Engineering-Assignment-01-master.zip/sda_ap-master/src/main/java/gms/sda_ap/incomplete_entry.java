package gms.sda_ap;

public class incomplete_entry extends Exception{
    public incomplete_entry(String message){
        super(message);
    }
}
