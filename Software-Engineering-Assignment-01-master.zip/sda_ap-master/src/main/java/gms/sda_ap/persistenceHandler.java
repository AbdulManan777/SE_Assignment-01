package gms.sda_ap;

public abstract class persistenceHandler{
    //public abstract void saveMember(customer c);
    //MemberDao md1 = new MemberDao();
    //md1.saveMember()

}
