package gms.sda_ap;

import java.util.ArrayList;

public class planList {
    private ArrayList<String> plan;
}
