package gms.sda_ap;

/*
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class unittest {
@Test
public void test1() {
	member obj=new member;
	member.setUsername("Saad");
	String get=obj.getUsername();
	assertTrue("Saad".equals(get));
}
@Test
public void test2() {
	member obj=new member;
	member.setPassword("talha");
	String get=obj.getPassword();
	assertTrue("talha".equals(get));
}
@Test
public void test3() {
	member obj=new member;
	member.setName("Manan");
	String get=obj.getName();
	assertTrue("Manan".equals(get));
}
@Test
public void test4() {
	member obj=new member;
	member.setGender("Male");
	String get=obj.getName();
	assertFalse("Female".equals(get));
}
@Test
public void test5() {
	trainer obj=new trainer;
	trainer.setUsername("Talha");
	String get=obj.getUsername();
	assertTrue("Talha".equals(get));
}
@Test
public void test6() {
	trainer obj=new trainer;
	trainer.setPassword("abc123");
	String get=obj.getPassword();
	assertFalse("jjkjkjhk".equals(get));
}
@Test
public void test7() {
	trainer obj=new trainer;
	trainer.setCnic("123456789123");
	String get=obj.getCnic();
	assertFalse("2341234234".equals(get));
}
@Test
public void test8() {
	trainer obj=new trainer;
	trainer.setNumber("0302-5421871");
	String get=obj.getNumber();
	assertTrue("0302-5421871".equals(get));
}
@Test
public void test9() {
	trainer obj=new trainer;
	trainer.setAge("20");
	String get=obj.getAge();
	assertTrue("20".equals(get));
}
@Test
public void test10() {
	trainer obj=new trainer;
	trainer.setSpeciality("Cardio");
	String get=obj.getSpeciality();
	assertTrue("Cardio".equals(get));
}
}
*/
