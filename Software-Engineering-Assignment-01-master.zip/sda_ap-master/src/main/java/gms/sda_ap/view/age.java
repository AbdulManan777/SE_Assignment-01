package gms.sda_ap.view;

public class age extends Exception{
    public age(String message){
        super(message);
    }
}
